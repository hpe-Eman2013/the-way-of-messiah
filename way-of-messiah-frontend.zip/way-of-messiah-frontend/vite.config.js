import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// https://vitejs.dev/config/
export default defineConfig({
    base: '/',
    plugins: [react()],
    server: {
        port: 5173,
        open: true,
    },
    build: {
        outDir: "dist",
    },
    resolve: {
        alias: {
            "@": "/src",
        },
    },
    // Enable fallback for SPA routing
    preview: {
        port: 4173,
        open: true,
    },
    base: "/",
});